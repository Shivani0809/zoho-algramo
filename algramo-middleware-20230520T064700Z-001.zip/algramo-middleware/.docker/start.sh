#!/bin/bash

# sleep 5
# /usr/sbin/apache2ctl -D FOREGROUND
