# [Algramo Middleware](https://www.zoho.com/crm/crmplus/) 

**Introduction**

Algramo Middleware is a php script which takes the bulk data from the MS SQL server database then convert bulk data into json and insert it into the Zoho CRM module (through the api) and also collect the reponses of the apis in the CSV file and mail to a relevant user.
Note:- For running script as to insert all data in module then have to pass queryparam (`type=bulk`) otherwise the script only insert or update data from yesterday.



## Versions

[<img src="https://www.php.net/downloads.php" width="60" height="60" />](https://www.php.net/downloads.php)

## Technologies stack
- apache2
- php8.1
- php8.1-curl
- sqlsrv
- pdo_sqlsrv

## Quick start

- Clone the repo: `git clone https://github.com/algramo/zoho-integration`.


## Enviroement Constant
There's a config.php file inside classes directory where need to set all the required global constant variables to run the script perfectly. If any value is incorrect then the script will show error.
There are all the required constant variables below:-

- SERVER_NAME
- DB_NAME
- USERNAME
- PASSWORD

- CLIENT_ID
- CLIENT_SECRET
- ACCOUNT_URL
- REFRESH_TOKEN

- SMTP_USERNAME
- SMTP_PASSWORD
- SMTP_SECURE
- SMTP_HOST
- SMTP_MAILNAME
- SMTP_PORT


## Documentation
The documentation for the Algramo Middleware modules are present on Zoho CRM [website](https://www.zoho.com/crm/crmplus/).


## File Structure
Within the download you'll find the following directories and files:

```
algramo-middleware
├── classes
│   ├── module
│   │   ├── clients.php
│   │   ├── locations.php
│   │   ├── productByClients.php
│   │   ├── products.php
│   │   ├── promos.php
│   ├── authentication.php
│   ├── config.php
│   ├── connection.php
│   ├── curl_service.php
│   ├── err_template.php
├── .gitignore
├── composer.json
├── composer.lock
├── index.php
└── csv
```




## Resources
- Zoho CRM: <https://www.zoho.com/crm/crmplus/>
- Zoho Documentation: <https://www.zoho.com/crm/developer/docs/api/v3/api-collection.html>
- Postman: <https://www.postman.com/>
- Postman Documentation: <https://www.postman.com/postman/workspace/postman-public-workspace/documentation/12959542-c8142d51-e97c-46b6-bd77-52bb66712c9a>




## Useful Links

- [Zoho](https://accounts.zoho.com)
- [Zoho CRM](https://www.zoho.com/crm/crmplus/)


