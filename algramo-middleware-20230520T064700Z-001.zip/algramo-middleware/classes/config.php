<?php
error_reporting(-1);

// Database connection required variables 
    // define("SERVER_NAME","algramosqldevchile.database.windows.net");
    // define("DB_NAME","TricicloDEV");
    // define("USERNAME","algramo");
    // define("PASSWORD","triciclo.2020");

// Zehntech Development Database connection required variables 
    define("SERVER_NAME","algramosqlprodchile.database.windows.net");
    define("DB_NAME","Report");
    define("USERNAME","external.zehntech");
    define("PASSWORD","N2Nta!J*mm~~S5MU");

// Zoho connection required variable     
    define("CLIENT_ID","1000.629OLFDS21PYGCNQLT2UM0PNVJR3YJ");
    define("CLIENT_SECRET","51e21411d49ce8e024a3718725bdaddf44755cad84");
    define("ACCOUNT_URL","https://accounts.zoho.com");
    define("REFRESH_TOKEN","1000.c2c10bfa6d81e8745a55a8e0382c3377.3ed9e276ebbebc75ac867b717abf8faf");    

// Zoho connection required variable     
    define("SMTP_USERNAME","mohit.zehntech@gmail.com");
    define("SMTP_PASSWORD","ujdivkelqjwhwdfc");
    define("SMTP_SECURE","tls");
    define("SMTP_HOST","smtp.gmail.com");  
    define("SMTP_MAILNAME","Mohit");  
    define("SMTP_PORT",587);  

// Zoho CRM Required Scopes
    // ZohoCRM.modules.ALL,
    // ZohoSearch.securesearch.READ
