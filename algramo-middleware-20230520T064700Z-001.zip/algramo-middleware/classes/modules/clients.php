<?php
class Clients {
    public $page_size = 100;
    public $data_coll = array();
    public $insert_data = [];
    public $update_data = [];
    public $file = 'Clients.csv';
    public $module_name = 'ClientsNew';
    public $table_name = 'report.Clients';

    function __construct($delete = false) {
        if($delete === true){
            $this->deleteData();
        }else{
            $this->getData();
        }
    }

    function getData() {
        global $conn;
        try {
            $query = "SELECT count(*) from report.Clients;";
            $result_set = $conn->query($query);
            $num_of_rows = $result_set->fetchColumn();
            if ($num_of_rows !== 0) {
                $total_count = ceil($num_of_rows / $this->page_size);
                for ($page_number = 1; $page_number <= $total_count; $page_number++) {
                    $this->insert_data = [];
                    $this->update_data = [];
                    $this->data_coll = [];
                    $this->getClientsData($page_number);
                }
            }
        }
        catch (Exception $e) {
            echo $e->getMessage() . '<br>';
            error_log("$e->getMessage()");
        }
    }

    function getClientsData($page_number) {
        global $conn, $start_date, $end_date;
        try {
            $sql = '';
            if (isset($_GET['type']) && $_GET['type'] == 'bulk') {
                $sql = "SELECT ProcessDate,UserId,Name,LastName,Phone,Email,CountryId,ValidatedPhone,ValidatedEmail,FacebookId,AppleId,GoogleId,ReferralCode,DeviceType,
                Credits,Points,Impact,PlasticImpact,CreateDate,UpdateDate,FirstDispensing,LastDispensing,FirstOrder,LastOrder
                FROM report.Clients ORDER BY UserId OFFSET " . ($page_number - 1) * $this->page_size . " ROWS FETCH NEXT " . $this->page_size . " ROWS ONLY";
            } else {
                $sql = "SELECT ProcessDate,UserId,Name,LastName,Phone,Email,CountryId,ValidatedPhone,ValidatedEmail,FacebookId,AppleId,GoogleId,ReferralCode,DeviceType,
                Credits,Points,Impact,PlasticImpact,CreateDate,UpdateDate,FirstDispensing,LastDispensing,FirstOrder,LastOrder
                FROM report.Clients where ProcessDate BETWEEN '$start_date' AND '$end_date' ORDER BY UserId OFFSET " . ($page_number - 1) * $this->page_size . " ROWS FETCH NEXT " . $this->page_size . " ROWS ONLY";
            }
            $result = $conn->query($sql);
            while ($a = $result->fetchObject()) {
                $this->searchClient($a);
            }
            $insert_data_up['data'] = $this->insert_data;
            $decoded_data = json_encode($insert_data_up); 
            $response = $this->insertClientsData($decoded_data);
            foreach (json_decode($decoded_data)->data as $i=>$res)  {
                $status = $response->data[$i]->status;
                $user_id = $res->User_Id;
                $message = $status !== 'success' ? $response->data[$i]->message : '';
                array_push($this->data_coll, [$user_id, $status, $message]);
            }
            if (!(isset($_GET['type']) && $_GET['type'] == 'bulk')) {
                foreach ($this->update_data as $key => $value) {
                    $update_data_up['data'] = [$value];
                    $response = $this->updateClientData($update_data_up);
                    array_push($this->data_coll, [$value['User_Id'], $response->data[0]->status, $response->data[0]->message]);
                }
            }
            $this->getDataCSV();
        }
        catch (Exception $e) {
            echo $e->getMessage();
            error_log("$e->getMessage()");
        }
    }
    
    function searchClient($user) {
        global $curl;
        try {
            $response = null;
            if (!(isset($_GET['type']) && $_GET['type'] == 'bulk')) {
                $url = "/crm/v3/ClientsNew/search?criteria=User_Id:equals:$user->UserId";
                $response = $curl->api('GET', $url);
            }
            $data_array = array(
                'Apple'=> $user->AppleId ?? '',
                'Cod_Ref'=>$user->ReferralCode ?? '',
                'Created_At'=>date("c", strtotime($user->CreateDate)),
                'Credits'=>$user->Credits ?? '',
                'Device_Type'=>$user->DeviceType ?? '',
                'Email'=>$user->Email,
                'Facebook'=>$user->FacebookId ?? '',
                'First_Name'=>$user->Name ??'',
                'Google'=>$user->GoogleId ?? '',
                'Id_Country'=>(string)$user->CountryId ?? '',
                'Impract'=>(int)$user->Impact,
                'Is_Email_Validate'=>boolval($user->ValidatedEmail),
                'Is_Phone_Validate'=>boolval($user->ValidatedPhone),
                'Last_Name'=>$user->LastName ?? '',
                'Points'=>(int)$user->Points,
                'Plastic_Impact'=>(int)$user->PlasticImpact,
                'Updated_At'=> date("c", strtotime($user->UpdateDate)),
                'Name'=>(int)$user->UserId,
                'First_Dispensing'=>$user->FirstDispensing,
                'Last_Dispensing'=>$user->LastDispensing,
                'First_Order'=>$user->FirstOrder,
                'Last_Order'=>$user->LastOrder,
                'Process_Date'=>(!empty($user->ProcessDate)) ? $user->ProcessDate : date("Y-m-d")
            );  
            if(!empty($user->Phone)){
                $data_array['Phone'] = (string)$user->Phone ?? '';
            } 
            if($response == null) {
                array_push($this->insert_data, $data_array);
            }
            else {
                $data = $response->data;
                $data_array['Record_Id'] = $data[0]->id;
                array_push($this->update_data, $data_array);
            }
        }
        catch (Throwable $th) {
            throw $th;
        }
    }

    function insertClientsData($insert_data) {
        global $curl;
        $url = '/crm/v3/ClientsNew';
        $response = $curl->api('POST', $url, $insert_data);
        return $response;
    }

    function updateClientData($update_data) {
        global $curl;
        $decoded_data = json_encode($update_data); 
        $url = "/crm/v3/ClientsNew/".$update_data['data'][0]['Record_Id'];
        $response = $curl->api('PUT', $url, $decoded_data);
        return $response;
    }

    function getDataCSV() {
        $file_located = file_exists($this->file);
        $fh = fopen($this->file, 'a+');
        if ($file_located === false) {
            $header = ['Id','Status','Error'];
            fputcsv($fh, $header );  
        }
        foreach ($this->data_coll as $row) {
            fputcsv($fh, $row);
        }
        fclose($fh);
    }

    function deleteData() {
        global $conn;
        $dataArray = [];
        try {
            $page = 1;
            $perpage = 50;
            $count = NULL;
            $this->getProductsFromZoho($dataArray, $perpage, $page, $count);
        }
        catch (Exception $e) {
            echo $e->getMessage() . '<br>';
            error_log("$e->getMessage()");
        }
    }

    function getProductsFromZoho(&$dataArray, $perpage, $page, $count) {
        global $curl;
        try {
            $response = null;
                
            $url = "/crm/v3/$this->module_name?fields=Email&per_page=$perpage&page=$page";
            $response = $curl->api('GET', $url);
            
            foreach ($response->data as $item_array) {
                array_push($dataArray, $item_array->id);
            }

            //call delete API for maximum 100 records
            $url = "/crm/v3/$this->module_name?ids=" . implode(',', $dataArray);
            $delete_response = $curl->api('DELETE', $url);

            //reset $dataArray for next page
            $dataArray = [];

            if($response->info->more_records == 1){
                // $count = $response->info->count + 100;
                // $page = $response->info->page + 1;
                $page = 1;
                $this->getProductsFromZoho($dataArray, $perpage, $page, $count);
            }
        }
        catch (Throwable $th) {
            throw $th;
        }
    }
}