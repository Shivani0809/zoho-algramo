<?php
class ProductByClients {
    public $page_size = 100;
    public $data_coll = array();
    public $insert_data = [];
    public $update_data = [];
    public $file = 'ProductByClients.csv';
    public $module_name = 'ProductByClientsNew1';
    public $table_name = 'report.ProductByClients';

    function __construct($delete = false) {
        if($delete === true){
            $this->deleteData();
        }else{
            $this->getData();
        }
    }

    function getData() {
        global $conn;
        try {
            $query = "SELECT count(*) from report.ProductByClients;";
            $result_set = $conn->query($query);
            $num_of_rows = $result_set->fetchColumn();
            if ($num_of_rows !== 0) {
                $total_count = ceil($num_of_rows / $this->page_size);
                for ($page_number = 1; $page_number <= $total_count; $page_number++) {
                    $this->insert_data = [];
                    $this->update_data = [];
                    $this->data_coll = [];
                    $this->getProductByClientsData($page_number);
                }
            }
        }
        catch (Exception $e) {
            echo $e->getMessage() . '<br>';
            error_log("$e->getMessage()");
        }
    }

    function getProductByClientsData($page_number) {
        global $conn, $start_date, $end_date;
        try {
            $sql = '';
            if (isset($_GET['type']) && $_GET['type'] == 'bulk') {
                $sql = "SELECT ProcessDate,UserId,ProductId,ProductClientId,QtyofDispenses,Purchases,DispensingAmount,Credits,
                FirstDispensingDate,LastDispensingDate,AvgDispensingAmount,MaxDispensingAmount,MinDispensingAmount,
                QtyofPackagesUsed,AvgDaysBetweenSales,LastDispeningAmount,Packages,LastOrder
                FROM report.ProductByClients ORDER BY UserId OFFSET " . ($page_number - 1) * $this->page_size . " ROWS FETCH NEXT " . $this->page_size . " ROWS ONLY";
            } else {
                $sql = "SELECT ProcessDate,UserId,ProductId,ProductClientId,QtyofDispenses,Purchases,DispensingAmount,Credits,
                FirstDispensingDate,LastDispensingDate,AvgDispensingAmount,MaxDispensingAmount,MinDispensingAmount,
                QtyofPackagesUsed,AvgDaysBetweenSales,LastDispeningAmount,Packages,LastOrder
                FROM report.ProductByClients where ProcessDate BETWEEN '$start_date' AND '$end_date' ORDER BY UserId OFFSET " . ($page_number - 1) * $this->page_size . " ROWS FETCH NEXT " . $this->page_size . " ROWS ONLY";
            }
            $result = $conn->query($sql);
            while ($a = $result->fetchObject()) {
                $this->searchProduct($a);
            }
            $insert_data_up['data'] = $this->insert_data;
            $decoded_data = json_encode($insert_data_up); 
            $response = $this->insertProductByClientsData($decoded_data);
            foreach (json_decode($decoded_data)->data as $i=>$res)  {
                $status = $response->data[$i]->status;
                $ProductClientId = $res->Product_Client_Id;
                $message = $status !== 'success' ? $response->data[$i]->message : '';
                array_push($this->data_coll, [$ProductClientId, $status, $message]);
            }
            if (!(isset($_GET['type']) && $_GET['type'] == 'bulk')) {
                foreach ($this->update_data as $key => $value) {
                    $update_data_up['data'] = [$value];
                    $response = $this->updateProductByClientsData($update_data_up);
                    array_push($this->data_coll, [$value['Product_Client_Id'], $response->data[0]->status, $response->data[0]->message]);
                }
            }
            $this->getDataCSV();
        }
        catch (Exception $e) {
            echo $e->getMessage();
            error_log("$e->getMessage()");
        }
    }
    
    function searchProduct($user) {
        global $curl;
        try {
            $response = null;
            if (!(isset($_GET['type']) && $_GET['type'] == 'bulk')) {
                $url = "/crm/v3/ProductByClientsNew1/search?criteria=Product_Client_Id:equals:$user->ProductClientId";
                $response = $curl->api('GET', $url);
            }
            $data_array =  
                array(
                    'Name'=>(string)$user->UserId,
                    'Product_Id'=>(int)$user->ProductId,
                    'Product_Client_Id'=>(int)$user->ProductClientId,
                    'QtyOfDispenses'=>(int)$user->QtyofDispenses,
                    'Purchases'=>(int)$user->Purchases,
                    'Dispensing_Amount'=>(double)$user->DispensingAmount,
                    'Credits'=>(double)$user->Credits,
                    'Avg_Dispensing_Amount'=>(double)$user->AvgDispensingAmount,
                    'Max_Dispensing_Amount'=>(double)$user->MaxDispensingAmount,
                    'Min_Dispensing_Amount'=>(double)$user->MinDispensingAmount,
                    'QtyofPackages_Used'=>$user->QtyofPackagesUsed,
                    'Avg_Days_Between_Sales'=>(double)$user->AvgDaysBetweenSales,
                    'Last_Dispensing_Amount'=>(double)$user->LastDispeningAmount,
                    'Packages'=>(int)$user->Packages,
                    'Last_Order'=>$user->LastOrder,
                    'Process_Date'=>(!empty($user->ProcessDate)) ? $user->ProcessDate : date("Y-m-d")
                );
            if(!empty($user->FirstDispensingDate)){
                $insert_data['First_Dispensing_Date'] = $user->FirstDispensingDate;
            } 
            if(!empty($user->LastDispensingDate)){
                $insert_data['Last_Dispensing_Date'] = $user->LastDispensingDate;
            } 
            if($response == null) {
                array_push($this->insert_data, $data_array);
            }
            else {
                $data = $response->data;
                $data_array['Record_Id'] = $data[0]->id;
                array_push($this->update_data, $data_array);
            }
        }
        catch (Throwable $th) {
            throw $th;
        }
    }

    function insertProductByClientsData($insert_data) {
        global $curl;
        $url = '/crm/v3/ProductByClientsNew1';
        $response = $curl->api('POST', $url, $insert_data);
        return $response;
    }

    function updateProductByClientsData($update_data) {
        global $curl;
        $decoded_data = json_encode($update_data); 
        $url = "/crm/v3/ProductByClientsNew1/".$update_data['data'][0]['Record_Id'];
        $response = $curl->api('PUT', $url, $decoded_data);
        return $response;
    }

    function getDataCSV() {
        $file_located = file_exists($this->file);
        $fh = fopen($this->file, 'a+');
        if ($file_located === false) {
            $header = ['ProductClientId','Status','Error'];
            fputcsv($fh, $header );  
        }
        foreach ($this->data_coll as $row) {
            fputcsv($fh, $row);
        }
        fclose($fh);
    }

    function deleteData() {
        global $conn;
        $dataArray = [];
        try {
            $page = 1;
            $perpage = 50;
            $count = NULL;
            $this->getProductsFromZoho($dataArray, $perpage, $page, $count);
        }
        catch (Exception $e) {
            echo $e->getMessage() . '<br>';
            error_log("$e->getMessage()");
        }
    }

    function getProductsFromZoho(&$dataArray, $perpage, $page, $count) {
        global $curl;
        try {
            $response = null;
                
            $url = "/crm/v3/$this->module_name?fields=Product_Client_Id&per_page=$perpage&page=$page";
            $response = $curl->api('GET', $url);
            
            foreach ($response->data as $item_array) {
                array_push($dataArray, $item_array->id);
            }

            //call delete API for maximum 100 records
            $url = "/crm/v3/$this->module_name?ids=" . implode(',', $dataArray);
            $delete_response = $curl->api('DELETE', $url);

            //reset $dataArray for next page
            $dataArray = [];

            if($response->info->more_records == 1){
                // $count = $response->info->count + 100;
                // $page = $response->info->page + 1;
                $page = 1;
                $this->getProductsFromZoho($dataArray, $perpage, $page, $count);
            }
        }
        catch (Throwable $th) {
            throw $th;
        }
    }
}