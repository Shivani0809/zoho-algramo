<?php
class Locations {
    public $page_size = 100;
    public $data_coll = array();
    public $insert_data = [];
    public $update_data = [];
    public $file = 'Locations.csv';
    public $module_name = 'LocationsNew';
    public $table_name = 'report.V_Locations';

    function __construct($delete = false) {
        if($delete === true){
            $this->deleteData();
        }else{
            $this->getData();
        }
    }

    function getData() {
        global $conn;
        try {
            $query = "SELECT count(*) from $this->table_name;";
            $result_set = $conn->query($query);
            $num_of_rows = $result_set->fetchColumn();
            if ($num_of_rows !== 0) {
                $total_count = ceil($num_of_rows / $this->page_size);
                for ($page_number = 1; $page_number <= $total_count; $page_number++) {
                    $this->insert_data = [];
                    $this->update_data = [];
                    $this->data_coll = [];
                    $this->getLocationsData($page_number);
                }
            }
        }
        catch (Exception $e) {
            echo $e->getMessage() . '<br>';
            error_log("$e->getMessage()");
        }
    }

    function getLocationsData($page_number) {
        global $conn, $start_date, $end_date;
        try {
            $sql = '';
            if (isset($_GET['type']) && $_GET['type'] == 'bulk') {
                $sql = "SELECT ProcessDate,LocationId,Location,Address,City,CountryId,BusinessModel,LocationType,CreationDate 
                FROM $this->table_name ORDER BY LocationId OFFSET " . ($page_number - 1) * $this->page_size . " ROWS FETCH NEXT " . $this->page_size . " ROWS ONLY";
            } else {
                $sql = "SELECT ProcessDate,LocationId,Location,Address,City,CountryId,BusinessModel,LocationType,CreationDate 
                FROM $this->table_name where ProcessDate BETWEEN '$start_date' AND '$end_date' ORDER BY LocationId OFFSET " . ($page_number - 1) * $this->page_size . " ROWS FETCH NEXT " . $this->page_size . " ROWS ONLY";
            }
            $result = $conn->query($sql);
            while ($a = $result->fetchObject()) {
                $this->searchLocationsData($a);
            }
            $insert_data_up['data'] = $this->insert_data;
            $decoded_data = json_encode($insert_data_up); 
            $response = $this->insertLocationsData($decoded_data);
            foreach (json_decode($decoded_data)->data as $i=>$res)  {
                $status = $response->data[$i]->status;
                $location_id = $res->Location_Id;
                $message = $status !== 'success' ? $response->data[$i]->message : '';
                array_push($this->data_coll, [$location_id, $status, $message]);
            }
            if (!(isset($_GET['type']) && $_GET['type'] == 'bulk')) {
                foreach ($this->update_data as $key => $value) {
                    $update_data_up['data'] = [$value];
                    $response = $this->updateLocationsData($update_data_up);
                    array_push($this->data_coll, [$value['Location_Id'], $response->data[0]->status, $response->data[0]->message]);
                }
            }
            $this->getProductsCSV();
        }
        catch (Exception $e) {
            echo $e->getMessage();
            error_log("$e->getMessage()");
        }
    }
    
    function searchLocationsData($user) {
        global $curl;
        try {
            $response = null;
            if (!(isset($_GET['type']) && $_GET['type'] == 'bulk')) {
                $url = "/crm/v3/$this->module_name/search?criteria=Location_Id:equals:$user->LocationId";
                $response = $curl->api('GET', $url);
            }
            $data_array =  
                array(
                    'Location_Id'=>(int)$user->LocationId,
                    'Name'=>(string)$user->Location ?? '',
                    'Address'=>$user->Address ?? '',
                    'City'=>$user->City ?? '',
                    'Country_Id'=>(string)$user->CountryId,
                    'Business_Model'=>(string)$user->BusinessModel ?? '',
                    'Location_Type'=>(string)$user->LocationType ?? '',
                    'Process_Date'=>(!empty($user->ProcessDate)) ? $user->ProcessDate : date("Y-m-d")
                );    
            if(!empty($user->CreationDate)){
                $data_array['Creation_Date'] = $user->CreationDate;
            }  
            if($response == null) {
                array_push($this->insert_data, $data_array);
            }
            else {
                $data = $response->data;
                $data_array['Record_Id'] = $data[0]->id;
                array_push($this->update_data, $data_array);
            }
        }
        catch (Throwable $th) {
            throw $th;
        }
    }

    function insertLocationsData($insert_data) {
        global $curl;
        $url = '/crm/v3/' . $this->module_name;
        $response = $curl->api('POST', $url, $insert_data);
        return $response;
    }

    function updateLocationsData($update_data) {
        global $curl;
        $decoded_data = json_encode($update_data); 
        $url = "/crm/v3/$this->module_name/".$update_data['data'][0]['Record_Id'];
        $response = $curl->api('PUT', $url, $decoded_data);
        return $response;
    }

    function getProductsCSV() {
        $file_located = file_exists($this->file);
        $fh = fopen($this->file, 'a+');
        if ($file_located === false) {
            $header = ['Id','Status','Error'];
            fputcsv($fh, $header );  
        }
        foreach ($this->data_coll as $row) {
            fputcsv($fh, $row);
        }
        fclose($fh);
    }

    function deleteData() {
        global $conn;
        $dataArray = [];
        try {
            $page = 1;
            $perpage = 50;
            $count = NULL;
            $this->getLocationsFromZoho($dataArray, $perpage, $page, $count);
        }
        catch (Exception $e) {
            echo $e->getMessage() . '<br>';
            error_log("$e->getMessage()");
        }
    }

    function getLocationsFromZoho(&$dataArray, $perpage, $page, $count) {
        global $curl;
        try {
            $response = null;
                
            $url = "/crm/v3/$this->module_name?fields=Location&per_page=$perpage&page=$page";
            $response = $curl->api('GET', $url);
            
            foreach ($response->data as $item_array) {
                array_push($dataArray, $item_array->id);
            }

            //call delete API for maximum 100 records
            $url = "/crm/v3/$this->module_name?ids=" . implode(',', $dataArray);
            $delete_response = $curl->api('DELETE', $url);

            //reset $dataArray for next page
            $dataArray = [];

            if($response->info->more_records == 1){
                // $count = $response->info->count + 100;
                // $page = $response->info->page + 1;
                $page = 1;
                $this->getLocationsFromZoho($dataArray, $perpage, $page, $count);
            }
        }
        catch (Throwable $th) {
            throw $th;
        }
    }
}