<?php
class Promos
{
    public $page_size = 100;
    public $data_coll = array();
    public $insert_data = [];
    public $update_data = [];
    public $file = 'Promos.csv';
    public $module_name = 'PromosNew';
    public $table_name = 'report.Promos';

    function __construct($delete = false) {
        if($delete === true){
            $this->deleteData();
        }else{
            $this->getData();
        }
    }

    function getData()
    {
        global $conn;
        try {
            $query = "SELECT count(*) from report.Promos;";
            $result_set = $conn->query($query);
            $num_of_rows = $result_set->fetchColumn();
            if ($num_of_rows !== 0) {
                $total_count = ceil($num_of_rows / $this->page_size);
                for ($page_number = 1; $page_number <= $total_count; $page_number++) {
                    $this->insert_data = [];
                    $this->update_data = [];
                    $this->data_coll = [];
                    $this->getPromosData($page_number);
                }
            }
        } catch (Exception $e) {
            echo $e->getMessage() . '<br>';
            error_log("$e->getMessage()");
        }
    }

    function getPromosData($page_number)
    {
        global $conn, $start_date, $end_date;
        try {
            $sql = '';
            if (isset($_GET['type']) && $_GET['type'] == 'bulk') {
                $sql = "SELECT ProcessDate,CreatedDate,UsedDate,ValidFrom,ValidTo,PromoClientId,UserId,PromoId,OrderNumber,
                ProviderId,ProductId,PackageId,CountryId,Code,Description,Policy,IsUsed,IsCumulative,Amount 
                FROM report.Promos ORDER BY UserId OFFSET " . ($page_number - 1) * $this->page_size . " ROWS FETCH NEXT " . $this->page_size . " ROWS ONLY";
            } else {
                $sql = "SELECT ProcessDate,CreatedDate,UsedDate,ValidFrom,ValidTo,PromoClientId,UserId,PromoId,OrderNumber,
                ProviderId,ProductId,PackageId,CountryId,Code,Description,Policy,IsUsed,IsCumulative,Amount 
                FROM report.Promos where ProcessDate BETWEEN '$start_date' AND '$end_date' ORDER BY UserId OFFSET " . ($page_number - 1) * $this->page_size . " ROWS FETCH NEXT " . $this->page_size . " ROWS ONLY";
            }
            $result = $conn->query($sql);
            while ($a = $result->fetchObject()) {
                $this->searchPromo($a);
            }
            $insert_data_up['data'] = $this->insert_data;
            $decoded_data = json_encode($insert_data_up);
            $response = $this->insertPromosData($decoded_data);
            foreach (json_decode($decoded_data)->data as $i => $res) {
                $status = $response->data[$i]->status;
                $promo_id = $res->Promo_Client_Id;
                $message = $status !== 'success' ? $response->data[$i]->message : '';
                array_push($this->data_coll, [$promo_id, $status, $message]);
            }
            if (!(isset($_GET['type']) && $_GET['type'] == 'bulk')) {
                foreach ($this->update_data as $key => $value) {
                    $update_data_up['data'] = [$value];
                    $response = $this->updatePromoData($update_data_up);
                    array_push($this->data_coll, [$value['Promo_Id'], $response->data[0]->status, $response->data[0]->message]);
                }
            }
            $this->getDataCSV();
        } catch (Exception $e) {
            echo $e->getMessage();
            error_log("$e->getMessage()");
        }
    }

    function searchPromo($user)
    {
        global $curl;
        try {
            $response = null;
            if (!(isset($_GET['type']) && $_GET['type'] == 'bulk')) {
                $url = "/crm/v3/PromosNew/search?criteria=Promo_Id:equals:$user->PromoId";
                $response = $curl->api('GET', $url);
            }
            $data_array = array(
                'Created_Date' => date("c", strtotime($user->CreatedDate)),
                'Used_Date' => date("c", strtotime($user->UsedDate)),
                'Promo_Client_Id' => (int)$user->PromoClientId,
                'Name' => (int)$user->UserId,
                'Promo_Id' => (int)$user->PromoId,
                'Order_Number' => (int)$user->OrderNumber,
                'Provider_Id' => (string)$user->ProviderId ?? '',
                'Product_Id' => (string)$user->ProductId ?? '',
                'Package_Id' => (string)$user->PackageId ?? '',
                'Country_Id' => (int)$user->CountryId,
                'Code' => (string)$user->Code ?? '',
                'Description' => (string)$user->Description ?? '',
                'Policy' => (string)$user->Policy ?? '',
                'Is_Used' => boolval($user->IsUsed),
                'Is_Cumulative' => boolval($user->IsCumulative),
                'Amount' => (float)$user->Amount,
                'Process_Date' => (!empty($user->ProcessDate)) ? $user->ProcessDate : date("Y-m-d"),
                'Valid_From' => (!empty($user->ValidFrom)) ? $user->ValidFrom : date("Y-m-d"),
                'Valid_To' => (!empty($user->ValidTo)) ? $user->ValidTo : date("Y-m-d")
            );
            if($response == null) {
                array_push($this->insert_data, $data_array);
            }
            else {
                $data = $response->data;
                $data_array['Record_Id'] = $data[0]->id;
                array_push($this->update_data, $data_array);
            }
        } catch (Throwable $th) {
            throw $th;
        }
    }

    function insertPromosData($insert_data)
    {
        global $curl;
        $url = '/crm/v3/PromosNew';
        $response = $curl->api('POST', $url, $insert_data);
        return $response;
    }

    function updatePromoData($update_data) {
        global $curl;
        $decoded_data = json_encode($update_data); 
        $url = "/crm/v3/PromosNew/".$update_data['data'][0]['Record_Id'];
        $response = $curl->api('PUT', $url, $decoded_data);
        return $response;
    }

    function getDataCSV()
    {
        $file_located = file_exists($this->file);
        $fh = fopen($this->file, 'a+');
        if ($file_located === false) {
            $header = ['Id', 'Status', 'Error'];
            fputcsv($fh, $header);
        }
        foreach ($this->data_coll as $row) {
            fputcsv($fh, $row);
        }
        fclose($fh);
    }

    function deleteData() {
        global $conn;
        $dataArray = [];
        try {
            $page = 1;
            $perpage = 50;
            $count = NULL;
            $this->getProductsFromZoho($dataArray, $perpage, $page, $count);
        }
        catch (Exception $e) {
            echo $e->getMessage() . '<br>';
            error_log("$e->getMessage()");
        }
    }

    function getProductsFromZoho(&$dataArray, $perpage, $page, $count) {
        global $curl;
        try {
            $response = null;
                
            $url = "/crm/v3/$this->module_name?fields=Promo_Id&per_page=$perpage&page=$page";
            $response = $curl->api('GET', $url);
            
            foreach ($response->data as $item_array) {
                array_push($dataArray, $item_array->id);
            }

            //call delete API for maximum 100 records
            $url = "/crm/v3/$this->module_name?ids=" . implode(',', $dataArray);
            $delete_response = $curl->api('DELETE', $url);

            //reset $dataArray for next page
            $dataArray = [];

            if($response->info->more_records == 1){
                // $count = $response->info->count + 100;
                // $page = $response->info->page + 1;
                $page = 1;
                $this->getProductsFromZoho($dataArray, $perpage, $page, $count);
            }
        }
        catch (Throwable $th) {
            throw $th;
        }
    }
}
