<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';
require 'vendor/autoload.php';

set_error_handler('errorHandler'); // this line of code sets an error handler custom function to handle any php error. And here we pass our custom function that name “errorHandler”

function errorHandler($errorNumber, $errorString, $errorFile, $errorLine)
{
    $emailMessage = '<h2>Error Reporting on :- </h2>[' . date("Y-m-d h:i:s", time()) . ']';
    $emailMessage .= "<h2>Error Number :- </h2>".print_r($errorNumber, true).'';
    $emailMessage .= "<h2>Error String :- </h2>".print_r($errorString, true).'';
    $emailMessage .= "<h2>Error File :- </h2>".print_r($errorFile, true).'';
    $emailMessage .= "<h2>Error Line :- </h2>".print_r($errorLine, true).'';

    //Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try {
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port       = 587;

        $mail->setFrom(SMTP_USERNAME, SMTP_MAILNAME);
        $mail->addAddress(SMTP_USERNAME, SMTP_MAILNAME);

        $mail->isHTML(true);
        $mail->Subject = 'Zoho Daily Process <info@address.com>' . "\r\n";
        $mail->Body    = $emailMessage;
        $mail->AltBody = 'There\'s an error on line no. '.$errorLine.', '.$errorString;
        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

function SendFile($attachment) {
    $mail = new PHPMailer(true);
    try {
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port       = SMTP_PORT;

        $mail->setFrom(SMTP_USERNAME, SMTP_MAILNAME);
        $mail->addAddress(SMTP_USERNAME, SMTP_MAILNAME);

        $mail->isHTML(true);
        $mail->Subject = 'Zoho Daily Process <info@address.com>' . "\r\n";
        $mail->Body    = 'Zoho '.$attachment.'module records collection';
        $mail->AddAttachment($attachment.'.csv');
        $mail->send();
        sleep(1);
        if (file_exists($attachment.'.csv')) {
            unlink($attachment.'.csv');
        }
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        if (file_exists($attachment.'.csv')) {
            unlink($attachment.'.csv');
        }
    }
}