<?php

class Authentication {

    function __construct() {
        $this->getAccessToken();
    }
    public function getAccessToken() {
        global $access_token, $api_domain, $token_type, $expire_in;
        $data = [
            'client_id' => CLIENT_ID,
            'client_secret' => CLIENT_SECRET,
            'refresh_token' => REFRESH_TOKEN,
            'grant_type' => 'refresh_token'
        ];
        try {
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => ACCOUNT_URL . '/oauth/v2/token',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => $data,
            ));
            $response = json_decode(curl_exec($curl));
            curl_close($curl);

            $access_token = $response->access_token;
            $api_domain = $response->api_domain;
            $token_type = $response->token_type;
            $expire_in = date('Y-m-d H:i:s', (time() + (int)$response->expires_in - 120));
        }
        catch (Throwable $th) {
            throw $th;
        }
    }
}
