<?php
  class DatabaseConnection {
    
    public function db_connect() {
      try {
        $conn = new PDO('sqlsrv:Server='.SERVER_NAME.';Database='.DB_NAME, USERNAME, PASSWORD);
        if ($conn) {
          return $conn;
        } else {
          throw new Exception('Unable to connect');
        }
      } catch(Exception $e){
        trigger_error( $e->getMessage());
        echo "Connection error.<br/>";
        die( print_r($e->getMessage()));
      }
      
    }

    /**
     *  Make async response
     */     
    function async_response($text = null) {
      #check if fastcgi_finish_request is callable
      if (is_callable('fastcgi_finish_request')) {
          if ($text !== null) {
              echo $text;
          }
          session_write_close();
          fastcgi_finish_request();
          return;
      }
      ignore_user_abort(true);
      ob_start();
      if ($text !== null) {
          echo $text;
      }
      $serverProtocol = filter_input(INPUT_SERVER, 'SERVER_PROTOCOL', FILTER_SANITIZE_STRING);
      header($serverProtocol . ' 200 OK');
      header('Content-Encoding: none');
      header('Content-Length: ' . ob_get_length());
      header('Connection: close');
      ob_end_flush();
      ob_flush();
      flush();
    }
  }