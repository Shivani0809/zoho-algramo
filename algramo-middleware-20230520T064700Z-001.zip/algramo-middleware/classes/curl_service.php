<?php
ini_set('max_execution_time', '0'); // To execute the script for infinite time
class CurlService {
    function __construct() {
    }

    function api($method, $url, $data = null) {
        global $expire_in, $auth;
        $date = date('Y-m-d H:i:s');
        if ($date > $expire_in) {
            $auth->getAccessToken();
        }
        global $access_token, $api_domain;
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $api_domain. $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_ENCODING, '');
        curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
        curl_setopt($curl,CURLOPT_TIMEOUT, 0);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl,CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        // curl_setopt($curl, CURLOPT_FAILONERROR, true);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        if (isset($data)) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Authorization: Bearer '. $access_token
        ));
        $response = json_decode(curl_exec($curl));
        
        if (curl_errno($curl)) {
            return curl_error($curl);
        }
        curl_close($curl);
        return $response;
    }
}