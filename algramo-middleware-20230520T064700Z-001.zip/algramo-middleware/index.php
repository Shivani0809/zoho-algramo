<?php  
 
    include_once("classes/config.php");  
    include_once("classes/mailer.php");  
    include_once("classes/authentication.php");  
    include_once("classes/connection.php");   
    include_once("classes/curl_service.php");
    include_once("classes/modules/clients.php");
    include_once("classes/modules/products.php");
    include_once("classes/modules/locations.php");
    include_once("classes/modules/promos.php");
    include_once("classes/modules/productByClients.php");
    $access_token;
    $api_domain;
    $token_type;
    $expire_in;
    $db = new DatabaseConnection();
    $conn = $db->db_connect();
    $db->async_response('The script will continue to run and notify you upon completion.');
    $auth = new Authentication();
    $curl = new CurlService();

    $start_date = date("Y-m-d", strtotime("-1 days"));
    $end_date = date("Y-m-d");
    
    // Checking for the Connection
    if( $conn && $access_token && $api_domain) {
        $time_start = microtime(true);
        $products = new Products();
        if (file_exists('Products.csv')) {
            SendFile('Products');
        }
        $locations = new Locations();
        if (file_exists('Locations.csv')) {
            SendFile('Locations');
        }
        $productbyclients = new ProductByClients();
        if (file_exists('ProductByClients.csv')) {
            SendFile('ProductByClients');
        }
        $promos = new Promos();
        if (file_exists('Promos.csv')) {
            SendFile('Promos');
        }
        $clients = new Clients();
        if (file_exists('Clients.csv')) {
            SendFile('Clients');
        }
        $time_end = microtime(true);
        $execution_time = ($time_end - $time_start)/60;
        echo '<b>Total Execution Time:</b> '.$execution_time.' Minutes';
    }
    
?> 
